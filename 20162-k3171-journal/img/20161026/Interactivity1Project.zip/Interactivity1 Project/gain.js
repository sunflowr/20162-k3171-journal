inlets = 1;

var sliderLeft =0;
var volumeLeft = 0;
var volumeRight = 0;
var volume = 80;

//The three standard functions that are called from connected devices.

function bang(){
	var leftGain = this.patcher.getnamed("leftGain");
	var rightGain = this.patcher.getnamed("rightGain");

}

function msg_float(f){
	//
	var leftGain = this.patcher.getnamed("leftGain");
	var rightGain = this.patcher.getnamed("rightGain");
	
	if (inlet==0){
		volume = 80;
		var vol = Math.abs(f - 63.5);
		if(vol > 40) {
			volume = vol * 2;
			}
			if(f == 0){
			volume=	127;
			}
		}
	post("volume: "+volume+"\n");
	volumeLeft = volume;
	volumeRight = volume;
	leftGain.set(volumeLeft);
	rightGain.set(volumeRight);

}


