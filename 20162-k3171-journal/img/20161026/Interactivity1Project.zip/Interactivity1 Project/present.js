//Set number inlets and outlets
inlets = 4;
outlets = 3;
var i = 0; 
var xArray = [];
var playing = 0;
var playing2 = 0;
var rotation = 0;

//called whenever a dial changes value 
function msg_float(f){
	//post("x is "+f+"\n");
	//post("Playing :" + playing + "\n");
	var myPlayList = this.patcher.getnamed("myPlayList");
	var myPlayList2 = this.patcher.getnamed("myPlayList2");
	//outlet(1, f);
	f=Math.round(f);
	if(inlet==0){
		//post("x is "+f+"\n");
		addToXArray(f);
	}
	if(inlet==2){
		f=Math.round(f);
		outlet(1,f);
		if( playing2 != 1){
	if (f > 75 ){
		myPlayList2.int(1);
		playing2 = 1;
		}
	}
	if (f <75) {
		myPlayList2.int(0);
		playing2 = 0;
		}
	}
	if (inlet==3){
		f=Math.round(f);
		outlet(2,f);
	}
	
}

//called whenever a integer changes on any inlet 
function msg_int(i){
	//post("Int: "+i);
}


//things happening once like a button press calls bang like click 
function bang(){
	var standardDeviationX = standardDeviation(xArray);
	i = standardDeviationX;
	i=Math.round(i);
	if(i>=127){
	i=0;
	}
	outlet(0,i);
	//post("Bang number: "+i+"\n");
	var standardDeviationX = standardDeviation(xArray);
	post("Standard Deviation :"+standardDeviationX+"\n");
	//post(i+"\n");
	
	sdPlay(standardDeviationX);

}

//Adds the number to an array with max 100 numbers
function addToXArray(x){
	if(xArray.length<=30){
		xArray.push(x);
	}
	if(xArray.length>30){
		xArray.push(x);
		xArray.shift();
	}
}


//Counts and returns standardeviation for an array 
function standardDeviation(array){
	var length = array.length;
	var sum = 0;
	var mean = 0;
	if(length>5){
		for(var i = 0;i<length;i++){
			sum = array[i]+ sum;
		}
		mean = sum/length;
		var sdsum = 0;
		for(var i=0;i<length;i=i+1){
			sdsum=sdsum+((array[i]-mean)*(array[i]-mean));
		}
		var varians = sdsum/length;
		var SD = Math.sqrt(varians);
	}else{
		SD=0;
	}
	return SD.toFixed(2);
}


//Plays different songs with respect to standarddeviation of the array
function sdPlay(sdX){
	var myPlayList = this.patcher.getnamed("myPlayList");
	var intensityTextEdit =  this.patcher.getnamed("intensityTextEdit");
 	//myPlayList.int(0);
	
	if( playing != 1){
	if (sdX > 2 ){
		myPlayList.int(1);
		playing = 1;
	}
	}
	if (sdX <2) {
		myPlayList.int(0);
		playing = 0;
		}

}